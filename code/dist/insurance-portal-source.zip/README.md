# Insurance Portal — Source Code

Document upload portal on AWS (region **us-east-1**). Users upload a file through a Flask web app running on EC2 behind an Application Load Balancer. The app stores the file in S3. An S3 event triggers a Lambda function that reads the object metadata and inserts a row into RDS MySQL, using credentials from Secrets Manager.

```mermaid
flowchart LR
    Browser --> ALB["ALB (HTTP 80)"]
    ALB --> EC2["EC2 Flask/gunicorn"]
    EC2 -->|"PutObject"| S3["S3"]
    S3 -->|"ObjectCreated event"| Lambda["Lambda process-uploaded-file"]
    Lambda -->|"GetSecretValue"| Secrets["Secrets Manager"]
    Lambda -->|"INSERT uploaded_files"| RDS["RDS MySQL"]
    Lambda --> Logs["CloudWatch Logs"]
```

## Contents

| Path | Purpose |
|---|---|
| `frontend/index.html` | Upload form (3 MB client-side limit) |
| `backend/app.py` | Flask app: `GET /` serves the form, `POST /upload` writes to S3 |
| `backend/requirements.txt` | Web app dependencies |
| `lambda/lambda_function.py` | Lambda `process-uploaded-file`: S3 metadata to RDS |
| `lambda/requirements.txt` | Lambda dependency (`pymysql`, deployed as a layer) |
| `deploy/user-data.sh` | EC2 launch template user data: installs and starts the app on port 80 |
| `database/schema.sql` | Creates database `insurance_portal` and table `uploaded_files` |
| `iam/ec2-instance-role-policy.json` | Inline policy for `ec2-instance-role` |
| `iam/lambda-execution-role-policy.json` | Inline policy for `lambda-execution-role` |
| `package.ps1` | Builds the Lambda ZIP, the layer ZIP, and the submission ZIP |

No credentials are stored in this code. EC2 uses its instance role, and Lambda reads the database password from Secrets Manager at runtime.

## Dependencies

| Component | Runtime | Packages |
|---|---|---|
| Web app (EC2) | Python 3 on Amazon Linux 2023 | `flask==3.0.0`, `boto3==1.34.0`, `gunicorn==21.2.0` |
| Lambda | Python 3.12 | `pymysql==1.2.3` (layer); `boto3` is built into the runtime |
| Database | RDS MySQL 8.0 | — |

## Configuration

| Setting | Where | Value |
|---|---|---|
| `S3_BUCKET` | EC2 environment (set in user data) | `insurance-portal-uploads-file` |
| `DB_HOST` | Lambda environment variable | RDS endpoint of `insurance-portal-db` |
| `DB_NAME` | Lambda environment variable | `insurance_portal` |
| `DB_SECRET_NAME` | Lambda environment variable | `insurance-portal-db-credentials` |

The Secrets Manager secret must be a JSON object with `username` and `password` keys (the "Credentials for Amazon RDS database" secret type produces this format).

---

## Setup instructions

### 1. Run the web app locally (optional)

Requires Python 3.10+ and AWS credentials with `s3:PutObject` on the bucket (for example via `aws configure`).

```powershell
cd code\backend
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:S3_BUCKET = "insurance-portal-uploads-file"
python app.py
```

Open http://localhost:5000 and upload a file. `app.py` loads the form from `../frontend`, so keep the `backend` and `frontend` folders side by side.

### 2. Build the deployment packages

From the `code` folder:

```powershell
.\package.ps1
```

This creates in `code\dist\`:

- `lambda-function.zip`: the function code.
- `pymysql-layer.zip`: the layer, with `pymysql` under `python/` as Lambda expects.
- `insurance-portal-source.zip`: the source submission (no installed dependencies).

On Linux/macOS the equivalent is:

```bash
cd code
zip -j lambda-function.zip lambda/lambda_function.py
pip install -r lambda/requirements.txt -t python/
zip -r pymysql-layer.zip python
```

---

## Deployment instructions (AWS Console, us-east-1)

Subnets, routing, and endpoints are described in `docs/Cloud_Architecture.md` at the repository root. The steps below cover what this code needs.

### Step 1: Network prerequisites

- VPC `insurance-portal-vpc` (`10.0.0.0/16`) with **DNS resolution** and **DNS hostnames** enabled.
- Public subnets `10.0.1.0/24`, `10.0.2.0/24`; private-app subnets `10.0.11.0/24`, `10.0.12.0/24`; private-db subnets `10.0.21.0/24`, `10.0.22.0/24`.
- Security groups:
  - `alb-sg`: HTTP 80 from `0.0.0.0/0`.
  - `ec2-app-sg`: HTTP 80 from `alb-sg`.
  - `lambda-sg`: HTTPS 443 from `lambda-sg` (for the Secrets Manager endpoint).
  - `rds-sg`: MySQL 3306 from `lambda-sg`.

### Step 2: S3 bucket

Create the private bucket `insurance-portal-uploads-file` with SSE-S3 encryption and Block Public Access on.

### Step 3: RDS database and secret

1. Create a DB subnet group `insurance-portal-db-subnet-group` with both private-db subnets.
2. Create RDS MySQL 8.0 `insurance-portal-db` (`db.t3.micro`, 10 GB, **Public access: No**, security group `rds-sg`).
3. Create the Secrets Manager secret `insurance-portal-db-credentials` (type: credentials for RDS) with the master username and password. Leave rotation off.
4. From a host inside the VPC that can reach port 3306 (temporarily), run `database/schema.sql`:

   ```bash
   mysql -h <rds-endpoint> -u <username> -p < database/schema.sql
   ```

   Remove any temporary access afterwards so that only `lambda-sg` reaches RDS.

### Step 4: IAM roles

- **`ec2-instance-role`** (trusted entity: EC2): attach `iam/ec2-instance-role-policy.json` as an inline policy.
- **`lambda-execution-role`** (trusted entity: Lambda): attach the managed policy `AWSLambdaVPCAccessExecutionRole`, plus `iam/lambda-execution-role-policy.json` as an inline policy.

### Step 5: Web tier (EC2 Auto Scaling behind ALB)

1. Create launch template `insurance-portal-it`: Amazon Linux 2023, `t2.micro`/`t3.micro`, security group `ec2-app-sg`, IAM instance profile `ec2-instance-role`, no public IP. Paste `deploy/user-data.sh` into **Advanced details → User data**.
2. Create target group `app-target-group`: instances, HTTP 80, health check path `/`.
3. Create ALB `insurance-portal-alb`: internet-facing, both public subnets, `alb-sg`, listener HTTP 80 forwarding to `app-target-group`.
4. Create Auto Scaling group `insurance-portal-asg`: launch template `insurance-portal-it`, both private-app subnets, attach to `app-target-group`, ELB health checks on. Desired 2, min 2, max 4, target tracking policy on average CPU utilization (50%).
5. Browse to the ALB DNS name and confirm the upload form loads.

`deploy/user-data.sh` embeds copies of `backend/app.py` and `frontend/index.html`. If you change either file, update the matching block in the user-data script and start an instance refresh on the Auto Scaling group.

On the instance, the app runs from `/home/ec2-user/app/`, and gunicorn logs to `/var/log/insurance-portal.log`.

### Step 6: Lambda function

1. **Lambda → Layers → Create layer**: name `pymysql-layer`, upload `dist/pymysql-layer.zip`, compatible runtime Python 3.12.
2. **Create function** `process-uploaded-file`: Python 3.12, execution role `lambda-execution-role`.
3. **Code → Upload from → .zip file**: upload `dist/lambda-function.zip`. Handler: `lambda_function.lambda_handler`.
4. **Layers → Add a layer**: custom layer `pymysql-layer`.
5. **Configuration → General**: timeout **30 seconds** (the default of 3 seconds is too short for a VPC cold start plus the DB connection).
6. **Configuration → Environment variables**: `DB_HOST`, `DB_NAME`, `DB_SECRET_NAME` (see Configuration above).
7. **Configuration → VPC**: `insurance-portal-vpc`, both private-app subnets, security group `lambda-sg`.

### Step 7: VPC endpoints (required for Lambda)

Lambda in the private subnets has no public IP, so it cannot reach S3 or Secrets Manager public APIs. Without these endpoints it times out after logging the object key.

- **`s3-gateway-endpoint`**: service `com.amazonaws.us-east-1.s3`, type Gateway, route table `private-app-route-table`.
- **`secretsmanager-endpoint`**: service `com.amazonaws.us-east-1.secretsmanager`, type Interface, both private-app subnets, security group `lambda-sg`, private DNS enabled.

### Step 8: S3 trigger

Lambda → `process-uploaded-file` → **Add trigger** → S3, bucket `insurance-portal-uploads-file`, event type **All object create events**.

### Step 9: Verify end to end

1. Upload a file through the ALB URL. The page shows `File '<name>' uploaded successfully!`.
2. Confirm the object in the S3 bucket.
3. In CloudWatch Logs `/aws/lambda/process-uploaded-file`, the latest stream shows:
   - `Triggered for object: s3://insurance-portal-uploads-file/<name>`
   - `File: <name>, Content-Type: <type>, Uploaded: <timestamp>`
   - `Fetched DB credentials from Secrets Manager` (on a cold start)
   - `Record inserted into RDS successfully`
4. Optionally, query `SELECT * FROM uploaded_files ORDER BY upload_timestamp DESC LIMIT 5;` from inside the VPC.

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| ALB returns 502/503 | Instances unhealthy: check `ec2-app-sg` allows 80 from `alb-sg`, and `/var/log/insurance-portal.log` on the instance |
| Upload returns 500 | `ec2-instance-role` missing `s3:PutObject`, or wrong `S3_BUCKET` |
| Lambda times out after the "Triggered" log | `s3-gateway-endpoint` missing from `private-app-route-table` |
| Lambda times out after the "Content-Type" log | `secretsmanager-endpoint` missing, private DNS off, or `lambda-sg` lacks the 443 self-rule |
| `No module named 'pymysql'` | Layer not attached, or ZIP lacks the top-level `python/` folder |
| MySQL connection timeout | `rds-sg` doesn't allow 3306 from `lambda-sg`, or wrong `DB_HOST` |
| `Unknown database` / table errors | `database/schema.sql` not run |

## Cleanup

Delete `secretsmanager-endpoint` first (billed hourly), then the S3 trigger, bucket contents and bucket, the Lambda function and layer, the Auto Scaling group and launch template, the ALB and target group, RDS, and the secret.
